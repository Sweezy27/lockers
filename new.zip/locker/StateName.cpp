//
//  StateName.cpp
//  cs3307 project
//
//  Created by ma c on 2019/10/31.
//  Copyright © 2019 ma c. All rights reserved.
//

#include <stdio.h>
#include "StateName.h"
/*
enum StateName{
    empty, full, block, expired
};*/
